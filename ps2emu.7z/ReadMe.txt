PS2EMU - PlayStation 2 Emulation Project

1. Introduction
2. Installation
3. MiniFAQ
4. The Team
5. Contact

1. Introduction
===============
PS2EMU is a software that tries to emulate the Sony PlayStation 2 (PS2).
If you use PS2EMU you agree with the conditions in TERMS.TXT


2. Installation
===============
* Unzip the binary package in a directory. Be sure that the original tree
  structure is mantained.
* Copy SCPH10000.BIN and ROM1.BIN files into BIOS directory. These files
  are not provided with PS2EMU.
* Copy your favourite PS2EMU compatible plugins into PLUGINS directory.
* Run 'PS2EMU.exe", configure the options and select some plugins.

3. MiniFAQ
==========

Q: What is PS2EMU?
A: PS2EMU is a "Work In Progress" (WIP) Playstation 2 emulator.
Actually, it is still in early stages of developement, although progress 
is made in a daily basis.

Q: Why doesn't XYZ game work?
A: PS2EMU is able to run some demos and very few games.
Alsom, its speed is still inferior to the 10% of the real performance of
a PS2 console.


Q: Why don't these games work?
A: PS2EMU is still in developement. 

Q: Where may I find demos for trying on PS2EMU?
A: You will be able to find some demos at http://www.ps2dev.org. 

Q: Does PS2EMU require a a PS2 BIOS.
A: PS2EMU, for the time being, absolutely requires a the SCPH10000 BIOS 
file, as well as the file known as ROM1.BIN in order to work.

Q: Where do I get the needed BIOS files?
A: You can dump (download) the BIOS from your own PS2.
DO NOT ask PS2EMU Team or anyone else for a BIOS, the BIOS is copyrighted 
by SONY and it is illegal to pirate it.

Q: Several artifacts/glitches are seen in games/demos... why is this?
A: PS2 emulation even right now is still incomplete.
Remember that PS2EMU is still a "Work in Progress" project.

Q: How can people help fix these bugs?
A: You can help by reporting these bugs to PS2EMU Team by email,
even sending us an screenshot (if something is seen),
also details on your system setup, and which plugins are you using
may help, in case of "incomplete" emulation.

Q: Do I need a DVD drive?
A: Positive, if you want to use a game stores in a DVD-ROM.
Many PS2 games are written to CDrom, but not all of them

Q: I hear no sound!
A: SPU2 Plugins are still in developement, by several third party
developers. Also, if emulation performance is very slow, most 
probably sound will be disrupted even if SPU2 plugins are fine.


4. The Team
===========

Roor Makurosu: Lead programmer, all-purpose multi-cultural full-featured emulator-developer.

Scar_T: Programmer (Plugins Interface, VIF Decoder, Compiler Macros).

Shunt: Programmer ( COP2/VPU ).


5. Contact
==========

If you want to contact the authors for any reason, including job offers and project proposals,
you may send us an email to ps2emu@efx2.com